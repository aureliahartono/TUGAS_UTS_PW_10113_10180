<div class="clearfix"></div>
         <footer class="site-footer">
            <div class="footer-inner bg-white">
               <div class="row">
                  <div class="col-sm-6">
                <center>  <h5><b>Made with <span style="font-size: 20px ;color: #00BFFF;" >&#10084;</span> by PREETI &copy;<?php echo date('Y')?></b></h5></center>
				<p><center>  <h5><b>Built with pure HTML, CSS, PHP, JavaScript and Bootstrap</b></h5></center></p>
				  <p></p><h5><b><a href="mailto:preetipradhan097@gmail.com">preetipradhan097@gmail.com</a></b></h5>
				  <p></p><h5><b><a href="https://www.instagram.com/_preeti_pradhan_?r=nametag" target="_blank"> INSTAGRAM</a></b></h5>
			      <p></p><h5><b><a href="https://www.facebook.com/preeti.pradhan.16752" target="_blank">FACEBOOK</a></b></h5>
				  <p></p><h5><b><a href="https://www.linkedin.com/in/preeti-93b72a1b5" target="_blank"> LINKEDIN</a></b></h5>
                  </div>                
               </div>
            </div>
         </footer>
</div>
      <script src="assets/js/vendor/jquery-2.1.4.min.js" type="text/javascript"></script>
      <script src="assets/js/popper.min.js" type="text/javascript"></script>
      <script src="assets/js/plugins.js" type="text/javascript"></script>
      <script src="assets/js/main.js" type="text/javascript"></script>
</body>
</html>
